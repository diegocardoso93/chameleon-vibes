
export type VibeCard = {
  id: number,
  image: string,
  sound: string,
}

const vibeCards: VibeCard[] = [{
  id: 1,
  image: '1.png',
  sound: 'b1.mp3',
}, {
  id: 2,
  image: '2.png',
  sound: 'b2.mp3',
}, {
  id: 3,
  image: '3.png',
  sound: 'b3.mp3',
}, {
  id: 4,
  image: '4.png',
  sound: 'b4.mp3',
}, {
  id: 5,
  image: '5.png',
  sound: 'b5.mp3',
}];

export default vibeCards;
