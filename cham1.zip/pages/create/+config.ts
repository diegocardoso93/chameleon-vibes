import type { Config } from "vike/types";

export default {
  ssr: false,
} satisfies Config;

