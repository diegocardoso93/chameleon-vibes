<!-- https://vike.dev/Head -->

<template>
  <meta name="keywords" content="chameleon vibes, music sync, beat, art">

  <meta property="og:title" content="Chameleon" />
  <meta property="og:site_name" content="Chameleon" />
  <meta property="og:type" content="website" />
  <meta property="og:description" content="chameleon vibes, music sync, beat, art" />
  <meta property="og:locale" content="en" />

  <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🦎</text></svg>">
  <link href="https://fonts.googleapis.com/css2?family=Arvo:ital,wght@0,400;0,700;1,400;1,700&amp;family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
</template>

<script setup lang="ts">
</script>
