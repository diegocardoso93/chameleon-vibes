<template>
  <div class="container">
      <div v-if="showChameleon" class="item">
        <div ref="chameleon" class="card active" style="background-image: url(../assets/icon.png);">
          <div class="card__filter"></div>
        </div>
        <button v-if="!btnHidden" class="btn00" @click="drawnCard()">open</button>
      </div>

      <div v-if="showDrawn" class="item">
        <div class="card active" :style="`background-image: url(../assets/${drawn.image});`">
          <div class="card__filter"></div>
        </div>
        <button class="btn00" @click="openPlayer(drawn.id)">rent</button>
      </div>

      <!-- <div v-for="(item) of items" :key="item.id" class="card" @click="goToImage(item.id)">
        <div class="card-img" :style="`background-image: url('${item.url}');`"></div>
        <div class="card-info">
          <h3>{{ item.title }}</h3>
        </div>
      </div> -->
  </div>
  <div>
    <div class="list">
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useData } from 'vike-vue/useData';
import { Data } from './+data';
import { ref } from 'vue';
import vibeCards from '../../common/vibeCards';

const { items } = useData<Data>();
console.log(items);

const btnHidden = ref();
const showChameleon = ref(true);
const chameleon = ref();
const showDrawn = ref(false);
const drawn = ref();

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));

async function drawnCard() {

  drawn.value = vibeCards[Math.floor((Math.random() * vibeCards.length))];

  btnHidden.value = true;
  const chameleonEl = chameleon.value;
  chameleonEl.classList.add('openning');
  await delay(2000);
  chameleonEl.classList.remove('openning');
  chameleonEl.classList.add('openning2');
  await delay(2000);
  chameleonEl.classList.add('zoomin');
  await delay(500);
  chameleonEl.classList.remove('zoomin');
  chameleonEl.classList.add('zoomout');
  await delay(600);
  showChameleon.value = false;
  showDrawn.value = true;
}

function openPlayer(id: number) {
  // @todo transaction call
  location.href = `/show?id=${id}`;
}
</script>

<style scoped>
.container {
  display: flex;
  width: 100%;
  justify-content: center;
  padding-top: 10px;
}
.list {
  width: 100%;
  max-width: 1024px;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  padding: 0;
  margin: 0;
  list-style: none;
}
@media (max-width: 1024px) {
  .list {
    grid-template-columns: repeat(2, 1fr);
  }
}
@media (max-width: 800px) {
  .list {
    grid-template-columns: 1fr;
  }
}

.item {
  display: flex;
  align-items: center;
  flex-direction: column;
}

.card {
  width: 300px;
  height: 300px;
  border-radius: 10px;
  overflow: hidden;

  border-radius: 10px;
  background-size: cover;
  position: relative;
  
  transition-duration: 300ms;
  transition-property: transform, box-shadow;
  transition-timing-function: ease-out;
  transform: rotate(0);

  z-index: -1;
}

.card:hover {
  scale: 1.1;
  transition: all 0.2s;
}

.card.active .card__filter:before, .card.active .card__filter:after {
  content: "";
  position: absolute;
  top: -10px;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 2;
  background: linear-gradient(130deg, #3d3d3d00 45%, #9e9bf84d 50%, #3d3d3d00 60%);
  background-size: 500%;
  background-position-x: 100%;
  filter: blur(8px);
  border-radius: 100px;
  mix-blend-mode: color-dodge;
  animation: shimmer 3s infinite linear;
}

@keyframes shimmer {
  100% {
    background-position-x: 0;
  }
}

.openning {
  transform: rotate(7200deg);
  transition-duration: 2.5s;
}
.openning2 {
  transform: rotate(3600deg);
  transition-duration: 2.5s;
}
.zoomin {
  transition: transform 0.5s ease;
  transform: scale(1.2);
}
.zoomout {
  transition: transform 0.5s ease;
  transform: scale(1);
}
/* .hide {
  display: none;
  transition: all 1s;
} */



.btn00 {
  min-width: 100px;
  padding: 10px;
  font-size: 20px;
  color: rgb(156, 255, 250);
  cursor: pointer;
  border: 0;
  border-radius: 6px;
  z-index: 3;
  position: relative;

  background: radial-gradient(141.42% 141.42% at 100% 0%, #fff6, #fff0), radial-gradient(140.35% 140.35% at 100% 94.74%, #bd34fe, #bd34fe00), radial-gradient(89.94% 89.94% at 18.42% 15.79%, #41d1ff, #41d1ff00);
  box-shadow: 0 1px #ffffffbf inset;
  transition: all 0.3s;
}
.btn00:hover {
  margin-top: -4px;
  box-shadow: 0 6px 20px 10px #9e9bf84d;
}


/* .card {
  border: 1px solid #000;
  color: white;
  padding: 10px;
  flex: 0 1 calc(33.33% - 10px);
  box-sizing: border-box;
  margin-top: 10px;
  cursor: pointer;
  background: beige;
}
.card-img {
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  height: 300px;
  border: 1px solid rgb(235, 236, 239);
  background-color: rgb(2 2 2);
}
.card-info {
  width: 100%;
  color: black;
}
.card-info h3 {
  font-family: 'Poppins', sans-serif;
  font-weight: 300;
  max-width: 308px;
  font-size: 16px;
  margin: 10px 0 0 0;
  height: 36px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 20px;
  text-overflow: ellipsis;
} */
</style>







<!-- <!DOCTYPE html>





    /* header area */
    #btnBack {
      width: 60px;
      cursor: pointer;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 11;
      padding: 20px;
      margin-top: 100px;
      display: none;
    }
    #player {
      position: fixed;
      background: black;
      width: 100vw;
      height: 100vh;
      z-index: 10;
      display: none;
      top: 100px;
      justify-content: center;
    }
    #player iframe {
      width: 100%;
      max-width: 500px;
      height: 500px;
      border: 0;
    }

  </style>
</head>

<body>

  <div id="player">
    <iframe src="about:blank"></iframe>
  </div>

  <img id="btnBack" src="/back.svg" onclick="hidePlayer()"/>

  <div style="display: flex;padding-top: 100px;">
    <div class="item">
      <div class="card active" style="background-image: url(/1.png);">
        <div class="card__filter"></div>
      </div>
      <button class="btn00" onclick="openPlayer('1')">open</button>
    </div>

    <div class="item">
      <div class="card active" style="background-image: url(/2.png);">
        <div class="card__filter"></div>
      </div>
      <button class="btn00" onclick="openPlayer('2')">open</button>
    </div>
    
    <div class="item">
      <div class="card active" style="background-image: url(/3.png);">
        <div class="card__filter"></div>
      </div>
      <button class="btn00" onclick="openPlayer('3')">open</button>
    </div>

    <div class="item">
      <div class="card active" style="background-image: url(/4.png);">
        <div class="card__filter"></div>
      </div>
      <button class="btn00" onclick="openPlayer('4')">open</button>
    </div>
  </div>

  <script>
    const options = [{
      id: 1,
      img: '/1.png',
      track: '1',
    }];

    const delay = (ms) => new Promise(res => setTimeout(res, ms));
    // function openPage(num) {
    //   location.href = '/s2.html?q=' + num;
    // }
    function hidePlayer() {
      document.querySelector('#player').style.display = 'none';
      document.querySelector('iframe').src = `about:blank`;
      document.querySelector('#btnBack').style.display = 'none';
    }
    function openPlayer(num) {
      document.querySelector('iframe').src = `/i2.html?q=${num}`;
      document.querySelector('#player').style.display = 'flex';
      document.querySelector('#btnBack').style.display = 'block';
    }
  </script>
</body>

</html>
 -->
